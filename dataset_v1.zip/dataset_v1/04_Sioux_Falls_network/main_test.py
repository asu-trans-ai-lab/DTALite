# -*- coding: utf-8 -*-
"""
Created on Sat Jun  3 17:03:02 2023

@author: 18016
"""
import path4gmns as pg
import os
os.chdir(r'C:\Users\18016\Documents\GitHub\DTALite\dataset_v1\02_Braess_Paradox')
pg.call_DTALite()


